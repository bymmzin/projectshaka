const gTTS = require('./lib/gTTS');
module.exports = gTTS;
